# colorunittest
PyPi package for reformatting and coloring unittest output in Jupyter Notebooks

## Installation
```pip install colorunittest```

## Description
To use, add the decorator `@run_unittest` to the unittest class and run cell.
![how to use](https://github.com/HilarieSit/colorunittest/blob/master/example_pic.png)